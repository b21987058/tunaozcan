package org.codeer.ICES4HU.Entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EvaluationAnswer {
    @Id
    @SequenceGenerator(name = "answer_id_sequence", sequenceName = "answer_id_sequence", allocationSize = 1, initialValue = 1)
    @GeneratedValue(generator = "answer_id_sequence", strategy = GenerationType.SEQUENCE)
    private Integer answer_id;
    private boolean is_choiceA_selected;
    private boolean is_choiceB_selected;
    private boolean is_choiceC_selected;
    private boolean is_choiceD_selected;
    private boolean is_choiceE_selected;
    private String open_ended_answer;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "evaluation_id")
    @JsonIgnore
    private Evaluation evaluation;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "survey_question_id")
    private SurveyQuestion surveyQuestion;
}
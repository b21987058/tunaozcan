package org.codeer.ICES4HU.Entity;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class QuestionType {
    @Id
    @SequenceGenerator(name = "question_type_id_sequence", sequenceName = "question_type_id_sequence", allocationSize = 1, initialValue = 1)
    @GeneratedValue(generator = "question_type_id_sequence", strategy = GenerationType.SEQUENCE)
    private Integer question_type_id;
    private String type;
}

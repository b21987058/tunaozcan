package org.codeer.ICES4HU.Repository;

import org.codeer.ICES4HU.Entity.Semester;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface SemesterRepository extends JpaRepository<Semester, Integer> {
    // find by courseId
    @Query("SELECT se.semester_id FROM Semester se INNER JOIN Section s WHERE s.course_id = ?1 AND s.semester_id = se.semester_id")
    Integer findByCourseId(Integer courseId);
}

package org.codeer.ICES4HU.Controller;

import java.util.List;
import java.util.Optional;

import org.codeer.ICES4HU.Entity.Evaluation;
import org.codeer.ICES4HU.Entity.EvaluationAnswer;
import org.codeer.ICES4HU.Entity.SurveyQuestion;
import org.codeer.ICES4HU.Repository.EvaluationAnswerRepository;
import org.codeer.ICES4HU.Repository.EvaluationRepository;
import org.codeer.ICES4HU.Repository.SurveyQuestionRepository;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin
@RestController
@RequestMapping("/api/v1/answers")
public class EvaluationAnswerController {
    private EvaluationAnswerRepository evaluationAnswerRepository;
    private EvaluationRepository evaluationRepository;
    private SurveyQuestionRepository surveyQuestionRepository;

    public EvaluationAnswerController(EvaluationAnswerRepository evaluationAnswerRepository,
            EvaluationRepository evaluationRepository, SurveyQuestionRepository surveyQuestionRepository) {
        this.evaluationAnswerRepository = evaluationAnswerRepository;
        this.evaluationRepository = evaluationRepository;
        this.surveyQuestionRepository = surveyQuestionRepository;
    }

    record EvaluationAnswerRequest(
            Integer evaluation_id,
            Integer survey_question_id,
            boolean is_choiceA_selected,
            boolean is_choiceB_selected,
            boolean is_choiceC_selected,
            boolean is_choiceD_selected,
            boolean is_choiceE_selected,
            String open_ended_answer) {

    }

    @GetMapping()
    public List<EvaluationAnswer> getAllEvaluationAnswers() {
        return evaluationAnswerRepository.findAll();
    }

    @PostMapping
    public void addEvaluationAnswer(@RequestBody EvaluationAnswerRequest ear) {
        EvaluationAnswer ea = new EvaluationAnswer();
        Optional<Evaluation> oe = evaluationRepository.findById(ear.evaluation_id());
        oe.ifPresent(e -> ea.setEvaluation(e));
        Optional<SurveyQuestion> osq = surveyQuestionRepository.findById(ear.survey_question_id());
        osq.ifPresent(sq -> ea.setSurveyQuestion(sq));
        ea.set_choiceA_selected(ear.is_choiceA_selected());
        ea.set_choiceB_selected(ear.is_choiceB_selected());
        ea.set_choiceC_selected(ear.is_choiceC_selected());
        ea.set_choiceD_selected(ear.is_choiceD_selected());
        ea.set_choiceE_selected(ear.is_choiceE_selected());
        ea.setOpen_ended_answer(ear.open_ended_answer());
        evaluationAnswerRepository.save(ea);
    }

    @PutMapping("/{answerId}")
    public void updateAnswer(
            @PathVariable("answerId") Integer answer_id,
            @RequestBody EvaluationAnswerRequest ear) {
        // Not implemented
        /*
         * EvaluationAnswer ea = evaluationAnswerRepository.findById(answer_id)
         * .orElseGet(() -> new EvaluationAnswer());
         * 
         * if (ear.evaluation_id() != null)
         * ea.setEvaluation_id(ear.evaluation_id());
         * if (ear.question_id() != null)
         * ea.setQuestion_id(ear.question_id());
         * ea.setIs_choiceA_selected(ear.is_choiceA_selected());
         * ea.setIs_choiceB_selected(ear.is_choiceB_selected());
         * ea.setIs_choiceC_selected(ear.is_choiceC_selected());
         * ea.setIs_choiceD_selected(ear.is_choiceD_selected());
         * ea.setIs_choiceE_selected(ear.is_choiceE_selected());
         * if (ear.open_ended_answer() != null)
         * ea.setOpen_ended_answer(ear.open_ended_answer());
         * 
         * evaluationAnswerRepository.save(ea);
         */
    }

    @DeleteMapping("/{answerId}")
    public void deleteEvaluationAnswer(@PathVariable("answerId") Integer answer_id) {
        evaluationAnswerRepository.deleteById(answer_id);
    }
}
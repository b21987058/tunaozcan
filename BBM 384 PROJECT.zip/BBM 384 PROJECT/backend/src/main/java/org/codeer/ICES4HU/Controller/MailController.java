package org.codeer.ICES4HU.Controller;

import org.codeer.ICES4HU.Service.MailService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin
@RestController
@RequestMapping("/api/v1/sendmail")
public class MailController {
    private final MailService mailService;

    public MailController(MailService mailService) {
        this.mailService = mailService;
    }

    record MailRecord(
            String from,
            String to,
            String subject,
            String body) {
    }

    @PostMapping()
    public void sendMail(@RequestBody MailRecord mr) {
        mailService.sendMail(mr.from(), mr.to(), mr.subject(), mr.body());
    }
}
package org.codeer.ICES4HU.Repository;

import org.codeer.ICES4HU.Entity.MailMerge;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MailMergeRepository extends JpaRepository<MailMerge, Integer> {

}

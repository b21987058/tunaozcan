package org.codeer.ICES4HU.AuthenticationToken;

public enum TokenType {
  BEARER
}

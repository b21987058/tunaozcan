package org.codeer.ICES4HU.Repository;

import org.codeer.ICES4HU.Entity.SectionEnrolment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SectionEnrolmentRepository extends JpaRepository<SectionEnrolment, Integer> {

}

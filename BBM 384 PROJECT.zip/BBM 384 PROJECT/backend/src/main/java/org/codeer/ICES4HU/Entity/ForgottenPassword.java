package org.codeer.ICES4HU.Entity;

import jakarta.persistence.*;

@Entity
public class ForgottenPassword {
    @Id
    @SequenceGenerator(name = "forgotten_password_id_sequence", sequenceName = "forgotten_password_id_sequence", allocationSize = 1, initialValue = 1)
    @GeneratedValue(generator = "forgotten_password_id_sequence", strategy = GenerationType.SEQUENCE)
    private Integer id;

    private String email;

    private boolean is_used;

    public ForgottenPassword() {
    }

    public ForgottenPassword(String email) {
        this.email = email;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public boolean isIs_used() {
        return is_used;
    }

    public void setIs_used(boolean is_used) {
        this.is_used = is_used;
    }
}

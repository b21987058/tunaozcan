package org.codeer.ICES4HU.Controller;

import org.codeer.ICES4HU.Entity.ForgottenPassword;
import org.codeer.ICES4HU.Repository.ForgottenPasswordRepository;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/api/v1/forgotten-password")
public class ForgottenPasswordController {
    private ForgottenPasswordRepository repository;

    record ForgottenPasswordRequest(String email) {
    }

    public ForgottenPasswordController(ForgottenPasswordRepository repository) {
        this.repository = repository;
    }

    @GetMapping()
    public List<ForgottenPassword> getAllForgottenPassword() {
        // return is used = false
        return repository.getForgottenPasswords();
    }

    @PostMapping()
    public void addForgottenPassword(@RequestBody ForgottenPasswordController.ForgottenPasswordRequest req) {
        repository.save(new ForgottenPassword(req.email()));
    }

    @PutMapping("/{forgottenPasswordId}")
    public void approveOrRejectRequest(
            @PathVariable("forgottenPasswordId") Integer forgottenPasswordId,
            @RequestBody boolean isApproved) {
        ForgottenPassword fp = repository.findById(forgottenPasswordId).orElseGet(() -> new ForgottenPassword());
        fp.setIs_used(true);

        if (isApproved) {
            // generate new password
            // update user password
            // send email to user
        }

        repository.save(fp);
    }

}

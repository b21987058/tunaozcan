package org.codeer.ICES4HU.Repository;

import org.codeer.ICES4HU.Entity.AcademicPersonnel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AcademicPersonnelRepository extends JpaRepository<AcademicPersonnel, Integer> {

}
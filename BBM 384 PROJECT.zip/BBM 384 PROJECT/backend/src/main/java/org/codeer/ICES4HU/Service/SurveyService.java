package org.codeer.ICES4HU.Service;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.codeer.ICES4HU.DTO.CourseDTO;
import org.codeer.ICES4HU.DTO.SurveyDTO;
import org.codeer.ICES4HU.Entity.Course;
import org.codeer.ICES4HU.Entity.Question;
import org.codeer.ICES4HU.Entity.Survey;
import org.codeer.ICES4HU.Entity.SurveyQuestion;
import org.codeer.ICES4HU.Repository.SurveyRepository;
import org.codeer.ICES4HU.Repository.CourseRepository;
import org.codeer.ICES4HU.Repository.QuestionRepository;
import org.codeer.ICES4HU.Repository.QuestionTypeRepository;
import org.codeer.ICES4HU.Repository.SurveyQuestionRepository;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;

@Service
public class SurveyService {
    public final SurveyRepository surveyRepository;
    public final QuestionRepository questionRepository;
    public final QuestionTypeRepository questionTypeRepository;
    public final SurveyQuestionRepository surveyQuestionRepository;
    public final CourseRepository courseRepository;

    public SurveyService(SurveyRepository surveyRepository, QuestionRepository questionRepository,
            QuestionTypeRepository questionTypeRepository, SurveyQuestionRepository surveyQuestionRepository,
            CourseRepository courseRepository) {
        this.surveyRepository = surveyRepository;
        this.questionRepository = questionRepository;
        this.questionTypeRepository = questionTypeRepository;
        this.surveyQuestionRepository = surveyQuestionRepository;
        this.courseRepository = courseRepository;
    }

    public SurveyDTO convertSurveyEntityToDTO(Survey survey) {
        SurveyDTO sdto = new SurveyDTO();
        sdto.setSurvey_id(survey.getSurvey_id());
        sdto.set_for_course(survey.is_for_course());
        sdto.setSection_id(survey.getSection_id());
        sdto.setStart_date(survey.getStart_date());
        sdto.setEnd_date(survey.getEnd_date());

        // Add questions
        Set<Question> questions = new HashSet<>();
        for (var sq : survey.getSurveyQuestions()) {
            questions.add(sq.getQuestion());
        }
        sdto.setQuestions(questions);
        return sdto;
    }

    public SurveyDTO convertSurveyAndQuestionsToDTO(Survey survey, Set<Question> questions) {
        SurveyDTO sdto = new SurveyDTO();
        sdto.set_for_course(survey.is_for_course());
        sdto.setSection_id(survey.getSection_id());
        sdto.setStart_date(survey.getStart_date());
        sdto.setEnd_date(survey.getEnd_date());
        sdto.setQuestions(questions);
        return sdto;
    }

    public void convertDTOtoEntitiesAndSave(SurveyDTO surveyDto) {
        // Create Survey entity and save
        Survey survey = new Survey();
        survey.setSurvey_id(surveyDto.getSurvey_id());
        survey.set_for_course(surveyDto.is_for_course());
        survey.setSection_id(surveyDto.getSection_id());
        survey.setStart_date(surveyDto.getStart_date());
        survey.setEnd_date(surveyDto.getEnd_date());
        survey.setSurveyQuestions(null);
        surveyRepository.save(survey);

        // Create Question and SurveyQuestion entities and save
        Set<Question> questions = surveyDto.getQuestions();
        int questionOrder = 0;
        for (var question : questions) {
            // Save Question entity
            questionRepository.save(question);

            // Create SurveyQuestion entity and save
            var surveyQuestion = new SurveyQuestion();
            surveyQuestion.setSurvey(survey);
            surveyQuestion.setQuestion(question);
            surveyQuestion.setQuestion_order(++questionOrder);
            surveyQuestionRepository.save(surveyQuestion);
        }
    }

    public Integer existsBySectionId(Integer course_id) {
        return surveyRepository.existsBySectionId(course_id);
    }

    public Integer existsByInstructorId(Integer course_id) {
        return surveyRepository.existsByInstructorId(course_id);
    }

    public Optional<Survey> getSurveyFromSection(Integer section_id) {
        Survey exampleSurvey = new Survey();
        exampleSurvey.setSection_id(section_id);
        Example<Survey> example = Example.of(exampleSurvey);
        return surveyRepository.findOne(example);
    }

    public List<SurveyDTO> getAllSurveys() {
        return surveyRepository
                .findAll()
                .stream()
                .map(s -> convertSurveyEntityToDTO(s))
                .toList();
    }

    public Optional<Survey> getSurvey(Integer survey_id) {
        return surveyRepository.findById(survey_id);
    }

    public void addSurvey(SurveyDTO sdto) {
        convertDTOtoEntitiesAndSave(sdto);
    }

    public void updateSurvey(SurveyDTO sdto) {
        // Not implemented
    }

    public void deleteSurvey(Integer survey_id) {
        surveyRepository.deleteById(survey_id);
    }
}

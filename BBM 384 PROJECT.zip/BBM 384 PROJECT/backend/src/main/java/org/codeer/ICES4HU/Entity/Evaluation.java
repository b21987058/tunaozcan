package org.codeer.ICES4HU.Entity;

import java.util.Set;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.SequenceGenerator;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Evaluation {
    @Id
    @SequenceGenerator(name = "evaluation_id_sequence", sequenceName = "evaluation_id_sequence", allocationSize = 1, initialValue = 1)
    @GeneratedValue(generator = "evaluation_id_sequence", strategy = GenerationType.SEQUENCE)
    private Integer evaluation_id;
    private Integer do_it_later_count;
    private boolean is_submitted;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "student_id")
    private Student student;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "survey_id")
    private Survey survey;

    @OneToMany(mappedBy = "evaluation")
    // EqualsAndHashCode and ToString is excluded from Lombok in order to prevent
    // infinite loop and stackoverflow
    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    private Set<EvaluationAnswer> answers;
}

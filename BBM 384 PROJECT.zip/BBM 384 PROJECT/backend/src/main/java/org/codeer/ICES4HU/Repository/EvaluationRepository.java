package org.codeer.ICES4HU.Repository;

import org.codeer.ICES4HU.Entity.Evaluation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EvaluationRepository extends JpaRepository<Evaluation, Integer> {

}

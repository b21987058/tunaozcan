package org.codeer.ICES4HU.Repository;

import org.codeer.ICES4HU.Entity.EvaluationAnswer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EvaluationAnswerRepository extends JpaRepository<EvaluationAnswer, Integer> {

}
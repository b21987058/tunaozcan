package org.codeer.ICES4HU.Controller;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.codeer.ICES4HU.DTO.EvaluationDTO;
import org.codeer.ICES4HU.DTO.SurveyDTO;
import org.codeer.ICES4HU.Entity.Evaluation;
import org.codeer.ICES4HU.Entity.EvaluationAnswer;
import org.codeer.ICES4HU.Entity.Student;
import org.codeer.ICES4HU.Entity.Survey;
import org.codeer.ICES4HU.Entity.SurveyQuestion;
import org.codeer.ICES4HU.Repository.SurveyQuestionRepository;
import org.codeer.ICES4HU.Service.EvaluationService;
import org.codeer.ICES4HU.Service.StudentService;
import org.codeer.ICES4HU.Service.SurveyService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@CrossOrigin
@RestController
@RequestMapping("/api/v1/evaluations")
public class EvaluationController {

    private static final Logger logger = LoggerFactory.getLogger(RestController.class);

    private EvaluationService evaluationService;
    private StudentService studentService;
    private SurveyService surveyService;
    private SurveyQuestionRepository surveyQuestionRepository;

    public EvaluationController(EvaluationService evaluationService, StudentService studentService,
                                SurveyService surveyService, SurveyQuestionRepository surveyQuestionRepository) {
        this.evaluationService = evaluationService;
        this.studentService = studentService;
        this.surveyService = surveyService;
        this.surveyQuestionRepository = surveyQuestionRepository;
    }

    record EmbeddedEvaluationAnswerRequest(
            Integer survey_question_id,
            boolean is_choiceA_selected,
            boolean is_choiceB_selected,
            boolean is_choiceC_selected,
            boolean is_choiceD_selected,
            boolean is_choiceE_selected,
            String open_ended_answer) {
    }

    record EvaluationRequest(
            Integer student_id,
            Integer survey_id,
            List<EmbeddedEvaluationAnswerRequest> answers) {
    }

    record IsEvaluatedSurveyRequest(
            Integer student_id,
            Integer survey_id) {
    }

    @GetMapping()
    public List<EvaluationDTO> getAllEvaluations() {
        logger.info("getAllEvaluations");
        return evaluationService.getAllEvaluationDTOs();
    }

    @GetMapping("/isEvaluatedSurvey")
    public boolean isEvaluatedSurvey(@RequestBody IsEvaluatedSurveyRequest input) {
        return evaluationService.isEvaluatedSurvey(input.student_id(), input.survey_id());
    }

    @GetMapping("/student_id/{student_id}")
    public List<EvaluationDTO> getEvaluationsByStudentId(@PathVariable("student_id") Integer student_id) {
        return evaluationService.getEvaluationsOfStudent(student_id);
    }

    @GetMapping("/survey_id/{survey_id}")
    public List<EvaluationDTO> getEvaluationBySurveyId(@PathVariable("survey_id") Integer survey_id) {
        return evaluationService.getEvaluationsOfSurvey(survey_id);
    }

    @PostMapping()
    public void addEvaluation(@RequestBody EvaluationRequest er) throws Exception {
        Evaluation evaluation = new Evaluation();
        Optional<Student> ostd = studentService.getStudentEntity(er.student_id());
        ostd.ifPresent(s -> evaluation.setStudent(s));
        Optional<Survey> osrvy = surveyService.getSurvey(er.survey_id());
        osrvy.ifPresent(srvy -> evaluation.setSurvey(srvy));

        // Default values
        evaluation.setDo_it_later_count(null);
        evaluation.set_submitted(false);

        // Add answers
        Set<EvaluationAnswer> answers = new HashSet<>();
        for (var ear : er.answers()) {
            EvaluationAnswer ea = new EvaluationAnswer();
            Optional<SurveyQuestion> osq = surveyQuestionRepository.findById(ear.survey_question_id());
            osq.ifPresent(sq -> ea.setSurveyQuestion(sq));
            // ea.setEvaluation(evaluation);
            ea.set_choiceA_selected(ear.is_choiceA_selected());
            ea.set_choiceB_selected(ear.is_choiceB_selected());
            ea.set_choiceC_selected(ear.is_choiceC_selected());
            ea.set_choiceD_selected(ear.is_choiceD_selected());
            ea.set_choiceE_selected(ear.is_choiceE_selected());
            ea.setOpen_ended_answer(ear.open_ended_answer());
            answers.add(ea);
        }

        EvaluationDTO edto = evaluationService.convertEvaluationAndAnswersToDTO(evaluation, answers);
        evaluationService.addEvaluation(edto);
    }

    @PutMapping("/{uid}")
    public void updateEvaluation(
            @PathVariable("uid") Integer uid,
            @RequestBody EvaluationRequest er) {
        // Not implemented
    }

    @DeleteMapping("/{uid}")
    public void deleteEvaluation(@PathVariable("uid") Integer uid) {
        evaluationService.deleteEvaluation(uid);
    }
}

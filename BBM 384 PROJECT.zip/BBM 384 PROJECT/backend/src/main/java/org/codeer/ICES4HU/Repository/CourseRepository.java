package org.codeer.ICES4HU.Repository;

import org.codeer.ICES4HU.DTO.CourseDTO;
import org.codeer.ICES4HU.Entity.Course;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface CourseRepository extends JpaRepository<Course, Integer> {
    @Query("SELECT new org.codeer.ICES4HU.DTO.CourseDTO(c.courseId, c.instructorId, c.departmentId, c.name, c.credits, s.semester_id) FROM Semester se INNER JOIN Section s INNER JOIN Course c WHERE s.course_id = ?1 AND s.semester_id = se.semester_id AND s.course_id = c.courseId")
    CourseDTO getCourseById(Integer courseId);

    @Query("SELECT c FROM Course c INNER JOIN Section s INNER JOIN SectionEnrolment se WHERE se.student_id = ?1 AND c.courseId = s.course_id AND se.section_id = s.section_id AND se.is_enrolled = true")
    List<Course> findByStudentId(Integer studentId);

    @Query("SELECT c FROM Course c INNER JOIN Section s WHERE c.courseId = s.course_id AND s.instructor_id = ?1 AND c.instructorId = ?1")
    List<Course> findByPersonId(Integer personId);

    @Query("SELECT c FROM Course c INNER JOIN Section s WHERE c.courseId = s.course_id AND c.departmentId = ?1")
    List<Course> findByDepartmentId(Integer departmentId);

    @Query("SELECT c FROM Course c INNER JOIN Section s INNER JOIN SectionEnrolment se WHERE se.student_id = ?1 AND c.courseId = s.course_id AND se.section_id = s.section_id AND se.is_enrolled = false AND c.departmentId = ?2")
    List<Course> findByDepartmentIdNotEnrolled(Integer studentId, Integer departmentId);
}

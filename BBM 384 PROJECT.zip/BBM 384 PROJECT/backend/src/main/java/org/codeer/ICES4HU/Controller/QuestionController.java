package org.codeer.ICES4HU.Controller;

import java.util.List;

import org.codeer.ICES4HU.Repository.QuestionRepository;
import org.codeer.ICES4HU.Repository.QuestionTypeRepository;
import org.codeer.ICES4HU.Entity.Question;
import org.codeer.ICES4HU.Entity.QuestionType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin
@RestController
@RequestMapping("/api/v1/questions")

public class QuestionController {

    private QuestionRepository questionRepository;
    private QuestionTypeRepository questionTypeRepository;

    record QuestionRequest(
            Integer written_by_instructor,
            Integer written_by_department,
            Integer course_id,
            boolean is_for_course,
            String question_text,
            String choiceA,
            String choiceB,
            String choiceC,
            String choiceD,
            String choiceE) {
    }

    public QuestionController(QuestionRepository questionRepository, QuestionTypeRepository questionTypeRepository) {
        this.questionRepository = questionRepository;
        this.questionTypeRepository = questionTypeRepository;
    }

    @GetMapping()
    public List<Question> getAllQuestions() {
        return questionRepository.findAll();
    }

    @PostMapping()
    public void addQuestion(@RequestBody QuestionRequest questionRequest) throws Exception {
        Question s = new Question();
        s.setWritten_by_instructor(questionRequest.written_by_instructor());
        s.setWritten_by_department(questionRequest.written_by_department());
        s.setCourse_id(questionRequest.course_id());
        s.set_for_course(questionRequest.is_for_course());
        s.setQuestion_text(questionRequest.question_text());
        s.setChoiceA(questionRequest.choiceA());
        s.setChoiceB(questionRequest.choiceB());
        s.setChoiceC(questionRequest.choiceC());
        s.setChoiceD(questionRequest.choiceD());
        s.setChoiceE(questionRequest.choiceE());

        // default values
        QuestionType qt1 = questionTypeRepository.findById(1)
                .orElseThrow(() -> new Exception("Question type no 1 does not exist in the database"));
        s.setQuestion_type(qt1);
        s.setQuestion_title(null);
        s.set_required(true);
        s.setQuestion_image_url(null);
        questionRepository.save(s);
    }

    @PutMapping("/{question_id}")
    public void updateQuestion(
            @PathVariable("question_id") Integer question_id,
            @RequestBody QuestionRequest qr) {
        Question q = questionRepository.findById(question_id).orElseGet(() -> new Question());
        if (qr.written_by_instructor() != null)
            q.setWritten_by_instructor(qr.written_by_instructor());
        if (qr.written_by_department() != null)
            q.setWritten_by_department(qr.written_by_department());
        if (qr.course_id() != null)
            q.setCourse_id(qr.course_id());
        if (qr.is_for_course())
            q.set_for_course(qr.is_for_course());
        if (qr.question_text() != null)
            q.setQuestion_text(qr.question_text());
        if (qr.choiceA() != null)
            q.setChoiceA(qr.choiceA());
        if (qr.choiceB() != null)
            q.setChoiceB(qr.choiceB());
        if (qr.choiceC() != null)
            q.setChoiceC(qr.choiceC());
        if (qr.choiceD() != null)
            q.setChoiceD(qr.choiceD());
        q.setChoiceE(qr.choiceE());
        questionRepository.save(q);
    }

    @DeleteMapping("/{question_id}")
    public void deleteQuestion(@PathVariable("question_id") Integer question_id) {
        questionRepository.deleteById(question_id);
    }
}

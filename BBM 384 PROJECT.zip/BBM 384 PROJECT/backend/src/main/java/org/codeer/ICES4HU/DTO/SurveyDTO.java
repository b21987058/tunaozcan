package org.codeer.ICES4HU.DTO;

import java.sql.Date;
import java.util.Set;

import org.codeer.ICES4HU.Entity.Question;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class SurveyDTO {
    private Integer survey_id;
    private Integer section_id;
    private boolean is_for_course;
    private boolean is_submitted;
    private Integer do_it_later_count;
    private boolean is_reevaluate_request_sent;
    private Date start_date;
    private Date end_date;

    private Set<Question> questions;
}

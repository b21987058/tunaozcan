package org.codeer.ICES4HU.Repository;

import org.codeer.ICES4HU.Entity.ForgottenPassword;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ForgottenPasswordRepository extends JpaRepository<ForgottenPassword, Integer> {
    // return is used = false
    @Query(value = "SELECT * FROM forgotten_password WHERE is_used = false", nativeQuery = true)
    List<ForgottenPassword> getForgottenPasswords();
}

package org.codeer.ICES4HU.Service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.codeer.ICES4HU.DTO.EvaluationDTO;
import org.codeer.ICES4HU.Entity.Evaluation;
import org.codeer.ICES4HU.Entity.EvaluationAnswer;
import org.codeer.ICES4HU.Repository.EvaluationAnswerRepository;
import org.codeer.ICES4HU.Repository.EvaluationRepository;
import org.codeer.ICES4HU.Repository.SurveyQuestionRepository;
import org.springframework.stereotype.Service;

@Service
public class EvaluationService {
    public final EvaluationRepository evaluationRepository;
    public final EvaluationAnswerRepository evaluationAnswerRepository;
    public final SurveyQuestionRepository surveyQuestionRepository;

    public EvaluationService(EvaluationRepository evaluationRepository,
            EvaluationAnswerRepository evaluationAnswerRepository, SurveyQuestionRepository surveyQuestionRepository) {
        this.evaluationRepository = evaluationRepository;
        this.evaluationAnswerRepository = evaluationAnswerRepository;
        this.surveyQuestionRepository = surveyQuestionRepository;
    }

    public EvaluationDTO convertEvaluationEntityToDTO(Evaluation evaluation) {
        EvaluationDTO edto = new EvaluationDTO();
        edto.setEvaluationId(evaluation.getEvaluation_id());
        edto.setSurvey(evaluation.getSurvey());
        edto.setStudent(evaluation.getStudent());
        edto.setSubmitted(evaluation.is_submitted());

        // Add answers
        // Set<EvaluationAnswer> answers = new HashSet<>();
        // for (var ea : evaluation.getAnswers()) {
        // answers.add(ea);
        // }
        // edto.setAnswers(answers);
        edto.setAnswers(evaluation.getAnswers());
        return edto;
    }

    public EvaluationDTO convertEvaluationAndAnswersToDTO(Evaluation evaluation, Set<EvaluationAnswer> answers) {
        EvaluationDTO edto = new EvaluationDTO();
        edto.setSurvey(evaluation.getSurvey());
        edto.setStudent(evaluation.getStudent());
        edto.setSubmitted(evaluation.is_submitted());
        edto.setAnswers(answers);
        return edto;
    }

    public void convertDTOtoEntitiesAndSave(EvaluationDTO edto) {
        // Create Evaluation entity and save
        Evaluation evaluation = new Evaluation();
        evaluation.setDo_it_later_count(null);
        evaluation.set_submitted(false);
        evaluation.setStudent(edto.getStudent());
        evaluation.setSurvey(edto.getSurvey());
        var savedEvaluation = evaluationRepository.save(evaluation);

        // Create EvaluationAnswer entities and save
        Set<EvaluationAnswer> answers = edto.getAnswers();
        for (var answer : answers) {
            // Save EvaluationAnswer entity
            answer.setEvaluation(savedEvaluation);
            evaluationAnswerRepository.save(answer);
        }

        // Add answers to the saved evaluation entity
        savedEvaluation.setAnswers(answers);
        evaluationRepository.save(savedEvaluation);
    }

    public List<EvaluationDTO> getEvaluationsOfSurvey(Integer survey_id) {
        List<Evaluation> allEvaluations = getAllEvaluations();
        List<EvaluationDTO> returnedEvaluationDTOs = new ArrayList<>();
        for (var e : allEvaluations) {
            if (e.getSurvey().getSurvey_id() == survey_id) {
                returnedEvaluationDTOs.add(convertEvaluationEntityToDTO(e));
            }
        }
        return returnedEvaluationDTOs;
    }

    public List<EvaluationDTO> getEvaluationsOfStudent(Integer student_id) {
        List<Evaluation> allEvaluations = getAllEvaluations();
        List<EvaluationDTO> returnedEvaluationDTOs = new ArrayList<>();
        for (var e : allEvaluations) {
            if (e.getStudent().getStudentId() == student_id) {
                returnedEvaluationDTOs.add(convertEvaluationEntityToDTO(e));
            }
        }
        return returnedEvaluationDTOs;
    }

    public Optional<EvaluationDTO> getEvaluationFromSurveyAndStudent(Integer survey_id, Integer student_id) {
        List<Evaluation> allEvaluations = getAllEvaluations();
        for (var e : allEvaluations) {
            if (e.getStudent().getStudentId() == student_id
                    && e.getSurvey().getSurvey_id() == survey_id) {
                return Optional.of(convertEvaluationEntityToDTO(e));
            }
        }
        return Optional.empty();
    }

    public List<Evaluation> getAllEvaluations() {
        return evaluationRepository.findAll();
    }

    public List<EvaluationDTO> getAllEvaluationDTOs() {
        return evaluationRepository
                .findAll()
                .stream()
                .map(e -> convertEvaluationEntityToDTO(e))
                .toList();
    }

    public Optional<EvaluationDTO> getEvaluation(Integer evaluation_id) {
        return evaluationRepository
                .findById(evaluation_id)
                .map(e -> convertEvaluationEntityToDTO(e));
    }

    public void addEvaluation(EvaluationDTO edto) {
        convertDTOtoEntitiesAndSave(edto);
    }

    public void updateSurvey(EvaluationDTO sdto) {
        // Not implemented
    }

    public void deleteEvaluation(Integer evaluation_id) {
        evaluationRepository.deleteById(evaluation_id);
    }

    public boolean isEvaluatedSurvey(Integer studentId, Integer surveyId) {
        return evaluationRepository
                .findAll()
                .stream()
                .anyMatch(e -> e.getStudent().getStudentId() == studentId
                        && e.getSurvey().getSurvey_id() == surveyId);
    }
}

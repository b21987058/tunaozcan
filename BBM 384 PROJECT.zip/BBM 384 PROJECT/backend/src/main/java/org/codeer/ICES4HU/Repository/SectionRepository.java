package org.codeer.ICES4HU.Repository;

import org.codeer.ICES4HU.Entity.Section;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface SectionRepository extends JpaRepository<Section, Integer> {
    @Query("SELECT s FROM Section s WHERE s.course_id = ?1")
    Optional<Section> findByCourseId(Integer courseId);
}

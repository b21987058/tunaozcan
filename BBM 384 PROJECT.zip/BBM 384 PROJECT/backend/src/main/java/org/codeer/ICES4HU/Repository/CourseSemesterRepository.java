package org.codeer.ICES4HU.Repository;

import org.codeer.ICES4HU.Entity.CourseSemester;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CourseSemesterRepository extends JpaRepository<CourseSemester, Integer> {

}

package org.codeer.ICES4HU.DTO;

public class CourseDTO {
    private Integer courseId;

    private Integer instructorId;

    private Integer departmentId;

    private String name;

    private Integer credits;

    private Integer semesterId;

    public CourseDTO() {
    }

    public CourseDTO(Integer courseId, Integer instructorId, Integer departmentId, String name, Integer credits, Integer semester_id) {
        this.courseId = courseId;
        this.instructorId = instructorId;
        this.departmentId = departmentId;
        this.name = name;
        this.credits = credits;
        this.semesterId = semester_id;
    }

    public Integer getCourseId() {
        return courseId;
    }

    public void setCourseId(Integer courseId) {
        this.courseId = courseId;
    }

    public Integer getInstructorId() {
        return instructorId;
    }

    public void setInstructorId(Integer instructorId) {
        this.instructorId = instructorId;
    }

    public Integer getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(Integer departmentId) {
        this.departmentId = departmentId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getCredits() {
        return credits;
    }

    public void setCredits(Integer credits) {
        this.credits = credits;
    }

    public Integer getSemesterId() {
        return semesterId;
    }

    public void setSemesterId(Integer semesterId) {
        this.semesterId = semesterId;
    }
}

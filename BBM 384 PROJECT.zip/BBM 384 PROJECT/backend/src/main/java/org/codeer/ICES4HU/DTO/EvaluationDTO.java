package org.codeer.ICES4HU.DTO;

import java.util.Set;

import org.codeer.ICES4HU.Entity.EvaluationAnswer;
import org.codeer.ICES4HU.Entity.Student;
import org.codeer.ICES4HU.Entity.Survey;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class EvaluationDTO {
    private Integer evaluationId;
    private Student student;
    private Survey survey;
    private boolean isSubmitted;

    private Set<EvaluationAnswer> answers;
}

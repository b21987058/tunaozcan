package org.codeer.ICES4HU.Controller;

import java.util.List;

import org.codeer.ICES4HU.Entity.SectionEnrolment;
import org.codeer.ICES4HU.Repository.SectionEnrolmentRepository;
import org.codeer.ICES4HU.Repository.SectionRepository;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin
@RestController
@RequestMapping("/api/v1/sectionenrolments")
public class SectionEnrolmentController {

    private SectionEnrolmentRepository sectionEnrolmentRepository;
    private SectionRepository sectionRepository;

    record SectionEnrolmentRequest(Integer course_id, Integer student_id, boolean is_enrolled) {
    }

    public SectionEnrolmentController(SectionEnrolmentRepository sectionEnrolmentRepository, SectionRepository sectionRepository) {
        this.sectionEnrolmentRepository = sectionEnrolmentRepository;
        this.sectionRepository = sectionRepository;
    }

    @GetMapping()
    public List<SectionEnrolment> getAllSectionEnrolments() {
        return sectionEnrolmentRepository.findAll();
    }

    @PostMapping()
    public void addSectionEnrolment(@RequestBody SectionEnrolmentRequest ser) {
        var section = sectionRepository.findByCourseId(ser.course_id()).orElseThrow();

        SectionEnrolment se = new SectionEnrolment();
        se.setSection_id(section.getSection_id());
        se.setStudent_id(ser.student_id());
        se.setIs_enrolled(ser.is_enrolled());
        sectionEnrolmentRepository.save(se);
    }

    @DeleteMapping("/{uid}")
    public void deleteSectionEnrolment(@PathVariable("uid") Integer uid) {
        sectionEnrolmentRepository.deleteById(uid);
    }
}

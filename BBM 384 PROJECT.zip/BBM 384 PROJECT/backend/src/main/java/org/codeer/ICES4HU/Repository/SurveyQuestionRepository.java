package org.codeer.ICES4HU.Repository;

import org.codeer.ICES4HU.Entity.SurveyQuestion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface SurveyQuestionRepository extends JpaRepository<SurveyQuestion, Integer> {
}

package org.codeer.ICES4HU.Controller;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.codeer.ICES4HU.DTO.SurveyDTO;
import org.codeer.ICES4HU.Entity.Question;
import org.codeer.ICES4HU.Entity.QuestionType;
import org.codeer.ICES4HU.Entity.Survey;
import org.codeer.ICES4HU.Repository.QuestionTypeRepository;
import org.codeer.ICES4HU.Repository.SectionRepository;
import org.codeer.ICES4HU.Repository.SurveyRepository;
import org.codeer.ICES4HU.Service.SurveyService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/api/v1/surveys")
public class SurveyController {

    private SurveyService surveyService;
    private QuestionTypeRepository questionTypeRepository;

    private SectionRepository sectionRepository;

    public SurveyController(SurveyService surveyService, QuestionTypeRepository questionTypeRepository, SectionRepository sectionRepository) {
        this.surveyService = surveyService;
        this.questionTypeRepository = questionTypeRepository;
        this.sectionRepository = sectionRepository;
    }

    record QuestionRequest(
            String question_text,
            String choiceA,
            String choiceB,
            String choiceC,
            String choiceD,
            String choiceE) {
    };

    record SurveyRequest(
            Integer written_by_instructor,
            Integer written_by_department,
            Integer course_id,
            boolean is_for_course,
            String start_date,
            String end_date,
            List<QuestionRequest> questions) {
    }

    record ExampleQuestion(String text, String ChoiceA, String ChoiceB) {
    }

    record Example(String start_date, String end_date, boolean is_for_course, Integer section_id,
            ExampleQuestion[] questions) {
    }

    record ExampleQuestionAnswer(Integer question_id, String ChoiceA, String ChoiceB) {
    }

    record ExampleAnswer(Integer student_id, Integer survey_id, ExampleQuestionAnswer[] answers) {
    }

    @GetMapping("/isCourseHasSurvey/{course_id}")
    public Integer isCourseHasSurvey(@PathVariable("course_id") Integer course_id) {
        return surveyService.existsBySectionId(course_id);
    }

    @GetMapping("/isInstructorHasSurvey/{course_id}")
    public Integer isInstructorHasSurvey(@PathVariable("course_id") Integer course_id) {
        return surveyService.existsByInstructorId(course_id);
    }

    @GetMapping()
    public List<SurveyDTO> getAllSurveys() {
        return surveyService.getAllSurveys();
    }

    @GetMapping("/section_id/{section_id}")
    public SurveyDTO getSurveyBySectionId(@PathVariable("section_id") Integer section_id) throws Exception {
        Integer surveyId = surveyService.existsBySectionId(section_id);
        if (surveyId == null)
            throw new Exception("No survey is found for the given section id.");
        Optional<Survey> survey = surveyService.getSurvey(surveyId);
        // Optional<Survey> survey = surveyService.getSurveyFromSection(section_id);
        Optional<SurveyDTO> surveyDto = survey.map(s -> surveyService.convertSurveyEntityToDTO(s));
        return surveyDto.orElseThrow(() -> new Exception("No survey exists."));
    }

    @PostMapping()
    public void addSurvey(@RequestBody SurveyRequest sr) throws Exception {

        var section = sectionRepository.findByCourseId(sr.course_id()).orElseThrow();

        Survey s = new Survey();
        s.setSection_id(section.getSection_id());
        s.set_for_course(sr.is_for_course());
        Date start_date = Date.valueOf(LocalDate.parse(sr.start_date()));
        s.setStart_date(start_date);
        Date end_date = Date.valueOf(LocalDate.parse(sr.end_date()));
        s.setEnd_date(end_date);

        // default values
        s.set_submitted(false);
        s.setDo_it_later_count(0);
        s.set_reevaluate_request_sent(false);

        // Add questions
        Set<Question> questions = new HashSet<>();
        for (var qr : sr.questions()) {
            Question q = new Question();
            q.setCourse_id(sr.course_id());
            q.setQuestion_text(qr.question_text());
            q.set_for_course(sr.is_for_course());
            q.setWritten_by_department(sr.written_by_department());
            q.setWritten_by_instructor(sr.written_by_instructor());
            q.setChoiceA(qr.choiceA());
            q.setChoiceB(qr.choiceB());
            q.setChoiceC(qr.choiceC());
            q.setChoiceD(qr.choiceD());
            q.setChoiceE(qr.choiceE());

            // default values
            QuestionType qt1 = questionTypeRepository.findById(1)
                    .orElseThrow(() -> new Exception("Question type no 1 does not exist in the database"));
            q.setQuestion_type(qt1);
            q.set_required(true);
            q.setQuestion_title(null);
            q.setQuestion_image_url(null);
            questions.add(q);
        }
        SurveyDTO sdto = surveyService.convertSurveyAndQuestionsToDTO(s, questions);
        surveyService.addSurvey(sdto);
    }

    @PutMapping("/{survey_id}")
    public void updateSurvey(
            @PathVariable("survey_id") Integer survey_id,
            @RequestBody SurveyRequest sr) {
        // Not implemented
        /*
         * Survey s = surveyService.getSurvey(survey_id).orElseGet(() -> new Survey());
         * if (sr.section_id() != null)
         * s.setSection_id(sr.section_id());
         * s.set_for_course(sr.is_for_course());
         * s.set_submitted(sr.is_submitted());
         * if (sr.start_date() != null) {
         * Date start_date = Date.valueOf(LocalDate.parse(sr.start_date()));
         * s.setStart_date(start_date);
         * }
         * if (sr.end_date() != null) {
         * Date end_date = Date.valueOf(LocalDate.parse(sr.end_date()));
         * s.setEnd_date(end_date);
         * }
         * SurveyDTO sdto = surveyService.convertEntityToDTO(s);
         * surveyService.updateSurvey(sdto);
         */
    }

    @DeleteMapping("/{survey_id}")
    public void deleteSurvey(@PathVariable("survey_id") Integer survey_id) {
        surveyService.deleteSurvey(survey_id);
    }
}

package org.codeer.ICES4HU.Repository;

import org.codeer.ICES4HU.Entity.QuestionType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface QuestionTypeRepository extends JpaRepository<QuestionType, Integer> {
}

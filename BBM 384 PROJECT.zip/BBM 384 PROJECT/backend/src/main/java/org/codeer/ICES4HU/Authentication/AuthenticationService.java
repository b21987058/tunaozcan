package org.codeer.ICES4HU.Authentication;

import org.codeer.ICES4HU.Config.JwtService;
import org.codeer.ICES4HU.AuthenticationToken.Token;
import org.codeer.ICES4HU.AuthenticationToken.TokenRepository;
import org.codeer.ICES4HU.AuthenticationToken.TokenType;
import org.codeer.ICES4HU.AuthenticationUser.Role;
import org.codeer.ICES4HU.AuthenticationUser.User;
import org.codeer.ICES4HU.AuthenticationUser.UserRepository;

import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;

import org.codeer.ICES4HU.Entity.AcademicPersonnel;
import org.codeer.ICES4HU.Entity.Department;
import org.codeer.ICES4HU.Entity.Student;
import org.codeer.ICES4HU.Repository.AcademicPersonnelRepository;
import org.codeer.ICES4HU.Repository.DepartmentRepository;
import org.codeer.ICES4HU.Repository.StudentRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.io.IOException;

@Service
@RequiredArgsConstructor
public class AuthenticationService {
    private final UserRepository repository;
    private final StudentRepository studentRepository;
    private final AcademicPersonnelRepository personnelRepository;
    private final TokenRepository tokenRepository;
    private final DepartmentRepository departmentRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final AuthenticationManager authenticationManager;

    @Value("${application.security.jwt.admin-password}")
    private String adminPassword;

    public AuthenticationResponse registerAdmin() {
        var user = User.builder()
                .name("admin")
                .surname("admin")
                .username("admin")
                .password(passwordEncoder.encode(adminPassword))
                .role(Role.ADMIN)
                .build();
        var savedUser = repository.save(user);
        var jwtToken = jwtService.generateAdminToken(user);
        var refreshToken = jwtService.generateAdminRefreshToken(user);
        saveUserToken(savedUser, jwtToken);
        return AuthenticationResponse.builder()
                .accessToken(jwtToken)
                .refreshToken(refreshToken)
                .build();
    }

    public AuthenticationResponse register(RegisterRequest request) {

        Integer studentId = null;
        Integer personnelId = null;

        var department = departmentRepository.findById(request.getDepartmentId()).orElseThrow();

        if (request.getRole() == Role.STUDENT) {
            // create new student by student repository

            var student = new Student();
            student.setName(request.getName());
            student.setSurname(request.getSurname());
            student.setEmail(request.getEmail());
            student.setUsername(request.getUsername());
            student.setDepartment(department);
            studentId = studentRepository.save(student).getStudentId();

        } else if (request.getRole() == Role.MANAGER) {
            // create new academic personnel by academic personnel repository

            var personnel = new AcademicPersonnel();
            personnel.setName(request.getName());
            personnel.setSurname(request.getSurname());
            personnel.setEmail(request.getEmail());
            personnel.setUsername(request.getUsername());
            personnel.setDepartment(department);
            personnel.setManagerOf(department);
            personnelId = personnelRepository.save(personnel).getPersonnelId();

        } else if (request.getRole() == Role.INSTRUCTOR) {
            // create new academic personnel by academic personnel repository
            var personnel = new AcademicPersonnel();
            personnel.setName(request.getName());
            personnel.setSurname(request.getSurname());
            personnel.setEmail(request.getEmail());
            personnel.setUsername(request.getUsername());
            personnel.setDepartment(department);
            personnelId = personnelRepository.save(personnel).getPersonnelId();
        }

        var user = User.builder()
                .name(request.getName())
                .surname(request.getSurname())
                .username(request.getUsername())
                .password(passwordEncoder.encode(request.getPassword()))
                .studentId(studentId)
                .personnelId(personnelId)
                .role(request.getRole())
                .build();

        var savedUser = repository.save(user);
        var jwtToken = jwtService.generateToken(user, request.getDepartmentId());
        var refreshToken = jwtService.generateRefreshToken(user);
        saveUserToken(savedUser, jwtToken);
        return AuthenticationResponse.builder()
                .accessToken(jwtToken)
                .refreshToken(refreshToken)
                .build();
    }

    public AuthenticationResponse authenticate(AuthenticationRequest request) {
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getUsername(),
                        request.getPassword()));
        var user = repository.findByUsername(request.getUsername())
                .orElseThrow();

        Department department = null;

        if (user.getRole() == Role.STUDENT) {
            var student = studentRepository.findById(user.getStudentId()).orElseThrow();

            if (student.getDepartment() != null) {
                department = student.getDepartment();
            } else {
                throw new IllegalArgumentException("User is not in this department");
            }

        } else if (user.getRole() == Role.MANAGER || user.getRole() == Role.INSTRUCTOR) {
            var personnel = personnelRepository.findById(user.getPersonnelId()).orElseThrow();

            if (personnel.getDepartment() != null) {
                department = personnel.getDepartment();
            } else {
                throw new IllegalArgumentException("User is not in this department");
            }

        } else if (user.getRole() == Role.ADMIN) {
            department = departmentRepository.findById(1).orElseThrow();
        }

        var jwtToken = jwtService.generateToken(user, department.getDepartment_id());
        var refreshToken = jwtService.generateRefreshToken(user);
        revokeAllUserTokens(user);
        saveUserToken(user, jwtToken);
        return AuthenticationResponse.builder()
                .accessToken(jwtToken)
                .refreshToken(refreshToken)
                .build();
    }

    private void saveUserToken(User user, String jwtToken) {
        var token = Token.builder()
                .user(user)
                .token(jwtToken)
                .tokenType(TokenType.BEARER)
                .expired(false)
                .revoked(false)
                .build();
        tokenRepository.save(token);
    }

    private void revokeAllUserTokens(User user) {
        var validUserTokens = tokenRepository.findAllValidTokenByUser(user.getId());
        if (validUserTokens.isEmpty())
            return;
        validUserTokens.forEach(token -> {
            token.setExpired(true);
            token.setRevoked(true);
        });
        tokenRepository.saveAll(validUserTokens);
    }

    public void refreshToken(
            HttpServletRequest request,
            HttpServletResponse response) throws IOException {
        final String authHeader = request.getHeader(HttpHeaders.AUTHORIZATION);
        final String refreshToken;
        final String username;
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            return;
        }
        refreshToken = authHeader.substring(7);
        username = jwtService.extractUsername(refreshToken);
        if (username != null) {
            var user = this.repository.findByUsername(username)
                    .orElseThrow();

            Department department = null;

            if (user.getRole() == Role.STUDENT) {
                var student = studentRepository.findById(user.getStudentId()).orElseThrow();

                if (student.getDepartment() != null) {
                    department = student.getDepartment();
                } else {
                    throw new IllegalArgumentException("User is not in this department");
                }

            } else if (user.getRole() == Role.MANAGER || user.getRole() == Role.INSTRUCTOR) {
                var personnel = personnelRepository.findById(user.getPersonnelId()).orElseThrow();

                if (personnel.getDepartment() != null) {
                    department = personnel.getDepartment();
                } else {
                    throw new IllegalArgumentException("User is not in this department");
                }

            }

            if (jwtService.isTokenValid(refreshToken, user)) {
                var accessToken = jwtService.generateToken(user, department.getDepartment_id());
                revokeAllUserTokens(user);
                saveUserToken(user, accessToken);
                var authResponse = AuthenticationResponse.builder()
                        .accessToken(accessToken)
                        .refreshToken(refreshToken)
                        .build();
                new ObjectMapper().writeValue(response.getOutputStream(), authResponse);
            }
        }
    }
}

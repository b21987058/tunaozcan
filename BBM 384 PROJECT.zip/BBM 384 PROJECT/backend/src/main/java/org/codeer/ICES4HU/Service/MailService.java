package org.codeer.ICES4HU.Service;

import java.util.Date;

import org.springframework.stereotype.Service;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MailService {
    private final MailMergeService mailMergeService;

    public MailService(MailMergeService mailMergeService) {
        this.mailMergeService = mailMergeService;
    }

    public void sendMail(String from, String to, String subject, String body) {
        // Check if the mail(to) exists in commonMails
        mailMergeService.getCommonMail(to).ifPresentOrElse((cm -> {
                    var mms = cm.getMailMerges();
                    mms.forEach(mm -> {
                        String studentEmail = mm.getStudent().getEmail();
                        sendMailWithTemplate(from, studentEmail, subject, body);
                    });
                }),
                // or else
                () -> sendMailWithTemplate(from, to, subject, body));
    }

    public void sendMailWithTemplate(String from, String to, String subject, String body) {
        var now = new Date();
        log.info("\nA mail is sent at " + now + "\nFrom: " + from + "\nTo: " + to + "\n" +
                "Subject: \n" + subject + "\n" + "Body: \n" + body + "\n");
    }
}
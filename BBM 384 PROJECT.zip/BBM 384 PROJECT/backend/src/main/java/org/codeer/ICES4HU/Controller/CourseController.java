package org.codeer.ICES4HU.Controller;

import java.util.List;

import org.codeer.ICES4HU.DTO.CourseDTO;
import org.codeer.ICES4HU.Entity.Course;
import org.codeer.ICES4HU.Repository.CourseRepository;
import org.codeer.ICES4HU.Repository.DepartmentRepository;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin
@RestController
@RequestMapping("/api/v1/courses")
public class CourseController {
    private CourseRepository courseRepository;
    private DepartmentRepository departmentRepository;

    record CourseRequest(Integer instructorId, Integer departmentId, String name, Integer credits) {
    }

    public CourseController(CourseRepository courseRepository, DepartmentRepository departmentRepository){
        this.courseRepository = courseRepository;
        this.departmentRepository = departmentRepository;
    }

    @GetMapping()
    public List<Course> getAllCourses() {
        return courseRepository.findAll();
    }

    @GetMapping("/student/{studentId}")
    public List<Course> getStudentCourses(@PathVariable("studentId") Integer studentId) {
        return courseRepository.findByStudentId(studentId);
    }

    @GetMapping("/instructor/{personId}")
    public List<Course> getInstructorCourses(@PathVariable("personId") Integer personId) {
        return courseRepository.findByPersonId(personId);
    }

    @GetMapping("/department/{departmentId}")
    public List<Course> getDepartmentCourses(@PathVariable("departmentId") Integer departmentId) {
        return courseRepository.findByDepartmentId(departmentId);
    }

    @GetMapping("/{courseId}")
    public CourseDTO getCourseById(@PathVariable("courseId") Integer courseId) {
        var dto = courseRepository.getCourseById(courseId);

        return dto;
    }

    @PostMapping()
    public Integer addCourse(@RequestBody CourseRequest courseRequest) {
        Course c = new Course();
        c.setDepartmentId(courseRequest.departmentId());
        c.setInstructorId(courseRequest.instructorId());
        c.setName(courseRequest.name());
        c.setCredits(courseRequest.credits());
        courseRepository.save(c);
        return c.getCourseId();
    }

    @PutMapping("/{courseId}")
    public void updateCourse(
            @PathVariable("courseId") Integer courseId,
            @RequestBody CourseRequest cr) {
        Course c = courseRepository.findById(courseId).orElseGet(() -> new Course());
        if (cr.departmentId() != null)
            c.setDepartmentId(cr.departmentId());
        c.setInstructorId(cr.instructorId);
        if (cr.name() != null)
            c.setName(cr.name());
        if (cr.credits() != null)
            c.setCredits(cr.credits());
        courseRepository.save(c);
    }

    @DeleteMapping("/{courseId}")
    public void deleteCourse(@PathVariable("courseId") Integer courseId) {
        courseRepository.deleteById(courseId);
    }
}

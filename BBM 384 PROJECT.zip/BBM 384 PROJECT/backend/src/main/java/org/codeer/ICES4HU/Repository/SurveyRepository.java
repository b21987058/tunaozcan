package org.codeer.ICES4HU.Repository;

import org.codeer.ICES4HU.Entity.Survey;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface SurveyRepository extends JpaRepository<Survey, Integer> {

    @Query("SELECT s.survey_id FROM Survey s INNER JOIN Section se WHERE s.section_id = se.section_id AND se.course_id = ?1 AND s.is_for_course = true")
    Integer existsBySectionId(Integer sectionId);

    @Query("SELECT s.survey_id FROM Survey s INNER JOIN Section se WHERE s.section_id = se.section_id AND se.course_id = ?1 AND s.is_for_course = false")
    Integer existsByInstructorId(Integer instructorId);
}

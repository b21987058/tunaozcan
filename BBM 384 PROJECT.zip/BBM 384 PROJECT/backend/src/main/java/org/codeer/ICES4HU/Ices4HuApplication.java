package org.codeer.ICES4HU;

import java.sql.Date;

import org.codeer.ICES4HU.Authentication.AuthenticationService;
import org.codeer.ICES4HU.Authentication.RegisterRequest;
import org.codeer.ICES4HU.AuthenticationUser.Role;
import org.codeer.ICES4HU.Entity.AcademicPersonnel;
import org.codeer.ICES4HU.Entity.Course;
import org.codeer.ICES4HU.Entity.Department;
import org.codeer.ICES4HU.Entity.QuestionType;
import org.codeer.ICES4HU.Entity.Section;
import org.codeer.ICES4HU.Entity.Semester;
import org.codeer.ICES4HU.Entity.Student;
import org.codeer.ICES4HU.Repository.CourseRepository;
import org.codeer.ICES4HU.Repository.QuestionTypeRepository;
import org.codeer.ICES4HU.Repository.SectionRepository;
import org.codeer.ICES4HU.Service.AcademicPersonnelService;
import org.codeer.ICES4HU.Service.DepartmentService;
import org.codeer.ICES4HU.Service.MailMergeService;
import org.codeer.ICES4HU.Service.MailService;
import org.codeer.ICES4HU.Service.SemesterService;
import org.codeer.ICES4HU.Service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@SpringBootApplication
public class Ices4HuApplication implements CommandLineRunner {

	@Autowired
	private AuthenticationService authenticationService;
	@Autowired
	private SemesterService semesterService;
	@Autowired
	private DepartmentService departmentService;
	@Autowired
	private AcademicPersonnelService academicPersonnelService;
	@Autowired
	private StudentService studentService;
	@Autowired
	private CourseRepository courseRepository;
	@Autowired
	private SectionRepository sectionRepository;
	@Autowired
	private QuestionTypeRepository questionTypeRepository;
	@Autowired
	private MailService mailService;
	@Autowired
	private MailMergeService mailMergeService;

	public static void main(String[] args) {
		SpringApplication.run(Ices4HuApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		/* cSpell:disable */

		// Admin is inserted on auth_user and auth_token tables with same tokens
		// Admin tokens do not change
		// Admin token:
		// eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZG1pbiIsImlhdCI6MTY4NDc5NjQ2NywiZXhwIjoxNjkzNDM2NDY3fQ.EsMsz5VOrmhNaDRydw-XiFoyUtg8zO4fpjWMPSFzxB8
		var authResponse = authenticationService.registerAdmin();
		System.out.println("Admin tokens: \n" + authResponse.getAccessToken() + "\n" + authResponse.getRefreshToken());

		// Add semesters
		Semester fall2022 = new Semester();
		fall2022.setName("2022 Fall");
		fall2022.setStart_date(Date.valueOf("2022-09-12"));
		fall2022.setEnd_date(Date.valueOf("2022-12-20"));
		semesterService.addSemester(fall2022);

		Semester spring2022 = new Semester();
		spring2022.setName("2022 Spring");
		spring2022.setStart_date(Date.valueOf("2023-01-05"));
		spring2022.setEnd_date(Date.valueOf("2023-06-20"));
		semesterService.addSemester(spring2022);

		Semester summer2022 = new Semester();
		summer2022.setName("2022 Summer");
		summer2022.setStart_date(Date.valueOf("2023-06-23"));
		summer2022.setEnd_date(Date.valueOf("2023-08-28"));
		summer2022.setIs_active(true);
		semesterService.addSemester(summer2022);

		final int CURRENT_SEMESTER_ID = 3;

		// Add departments
		Department physics = new Department();
		physics.setName("Physics");
		departmentService.addDepartment(physics);

		Department mathematics = new Department();
		mathematics.setName("Mathematics");
		departmentService.addDepartment(mathematics);

		Department computerEngineering = new Department();
		computerEngineering.setName("Computer Engineering");
		departmentService.addDepartment(computerEngineering);

		// Add academic personnel
		var request1 = new RegisterRequest();
		request1.setName("Ali");
		request1.setSurname("Taner");
		request1.setUsername("ali.taner");
		request1.setPassword("123456");
		request1.setEmail("ali.taner@example.com");
		request1.setRole(Role.INSTRUCTOR);
		request1.setDepartmentId(1);
		authenticationService.register(request1);

		var request2 = new RegisterRequest();
		request2.setName("Ada");
		request2.setSurname("Tanık");
		request2.setUsername("ada.tanik");
		request2.setPassword("123456");
		request2.setEmail("ada.tanik@example.com");
		request2.setRole(Role.MANAGER);
		request2.setDepartmentId(2);
		authenticationService.register(request2);

		var request3 = new RegisterRequest();
		request3.setName("Ayşe");
		request3.setSurname("Can");
		request3.setUsername("ayse.can");
		request3.setPassword("123456");
		request3.setEmail("ayse.can@example.com");
		request3.setRole(Role.INSTRUCTOR);
		request3.setDepartmentId(3);
		authenticationService.register(request3);

		// Add courses
		Course c1 = new Course();
		c1.setDepartmentId(1);
		c1.setInstructorId(1);
		c1.setName("Introduction to Physics I");
		c1.setCredits(4);
		courseRepository.save(c1);

		Course c2 = new Course();
		c2.setDepartmentId(1);
		c2.setInstructorId(1);
		c2.setName("Introduction to Physics II");
		c2.setCredits(4);
		courseRepository.save(c2);

		Course c3 = new Course();
		c3.setDepartmentId(2);
		c3.setInstructorId(2);
		c3.setName("Calculus 101");
		c3.setCredits(3);
		courseRepository.save(c3);

		Course c4 = new Course();
		c4.setDepartmentId(2);
		c4.setInstructorId(2);
		c4.setName("Calculus 102");
		c4.setCredits(4);
		courseRepository.save(c4);

		Course c5 = new Course();
		c5.setDepartmentId(3);
		c5.setInstructorId(3);
		c5.setName("Object Oriented Programming I");
		c5.setCredits(3);
		courseRepository.save(c5);

		Course c6 = new Course();
		c6.setDepartmentId(3);
		c6.setInstructorId(3);
		c6.setName("Object Oriented Programming II");
		c6.setCredits(4);
		courseRepository.save(c6);

		// Add sections
		Section sec1 = new Section();
		// sec1.setSection_no(1);
		sec1.setCourse_id(1);
		sec1.setInstructor_id(1);
		sec1.setSemester_id(CURRENT_SEMESTER_ID);
		sectionRepository.save(sec1);

		Section sec2 = new Section();
		sec2.setCourse_id(2);
		sec2.setInstructor_id(1);
		sec2.setSemester_id(CURRENT_SEMESTER_ID);
		sectionRepository.save(sec2);

		Section sec3 = new Section();
		sec3.setCourse_id(3);
		sec3.setInstructor_id(2);
		sec3.setSemester_id(CURRENT_SEMESTER_ID);
		sectionRepository.save(sec3);

		Section sec4 = new Section();
		sec4.setCourse_id(4);
		sec4.setInstructor_id(2);
		sec4.setSemester_id(CURRENT_SEMESTER_ID);
		sectionRepository.save(sec4);

		Section sec5 = new Section();
		sec5.setCourse_id(5);
		sec5.setInstructor_id(3);
		sec5.setSemester_id(CURRENT_SEMESTER_ID);
		sectionRepository.save(sec5);

		Section sec6 = new Section();
		sec6.setCourse_id(6);
		sec6.setInstructor_id(3);
		sec6.setSemester_id(CURRENT_SEMESTER_ID);
		sectionRepository.save(sec6);

		// Add students

		var s1 = new RegisterRequest();
		s1.setName("Cemal");
		s1.setSurname("Demir");
		s1.setUsername("cemal.demir");
		s1.setPassword("123456");
		s1.setEmail("cemal.demir@example.com");
		s1.setRole(Role.STUDENT);
		s1.setDepartmentId(physics.getDepartment_id());

		authenticationService.register(s1);

		var s2 = new RegisterRequest();
		s2.setName("Neşe");
		s2.setSurname("Budak");
		s2.setUsername("nese.budak");
		s2.setPassword("123456");
		s2.setEmail("nese.budak@example.com");
		s2.setRole(Role.STUDENT);
		s2.setDepartmentId(mathematics.getDepartment_id());

		authenticationService.register(s2);

		var s3 = new RegisterRequest();
		s3.setName("Ahmet");
		s3.setSurname("Cem");
		s3.setUsername("ahmet.cem");
		s3.setPassword("123456");
		s3.setEmail("ahmet.cem@example.com");
		s3.setRole(Role.STUDENT);
		s3.setDepartmentId(computerEngineering.getDepartment_id());

		authenticationService.register(s3);

		// Add question types
		QuestionType qt1 = new QuestionType();
		qt1.setType("SingleSelection");
		questionTypeRepository.save(qt1);

		QuestionType qt2 = new QuestionType();
		qt2.setType("MultipleSelection");
		questionTypeRepository.save(qt2);

		QuestionType qt3 = new QuestionType();
		qt3.setType("TrueFalse");
		questionTypeRepository.save(qt3);

		QuestionType qt4 = new QuestionType();
		qt4.setType("OpenEnded");
		questionTypeRepository.save(qt4);

		// Mail Merges
		// mailMergeService.addStudentToCommonMail(1, "ortakmail@example.com");
		// mailMergeService.addStudentToCommonMail(2, "ortakmail@example.com");

		// mailService.sendMail("from@example.com", "to@example.com", "mail subject",
		// "mail body");

	}

	@Bean
	public WebMvcConfigurer corsConfigurer() {
		return new WebMvcConfigurer() {
			@Override
			public void addCorsMappings(CorsRegistry registry) {
				registry.addMapping("/**").allowedOrigins("*").allowedHeaders("*").allowedMethods("*");
			}
		};
	}
}